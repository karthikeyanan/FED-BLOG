import React from "react";

const AddOn = () => {
  return <h1 className="addon">Add On New Topic Here</h1>;
};

export default AddOn;
