export const MenuItems = [
    {
      title: "Conferences",
      path: "/conferences",
      cName: "dropdown-link",
    },
    {
      title: "Journals",
      path: "/journals",
      cName: "dropdown-link",
    },
  ];
  