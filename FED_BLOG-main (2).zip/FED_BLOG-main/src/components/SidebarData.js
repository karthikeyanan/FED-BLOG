export const SidebarData = [
    {
      title: "Class Component",
      link: "/classcomponent",
    },
    {
      title: "add on 1",
      link: "/addon1",
    },
    {
      title: "add on 2",
      link: "/addon1",
    },
  ];
  