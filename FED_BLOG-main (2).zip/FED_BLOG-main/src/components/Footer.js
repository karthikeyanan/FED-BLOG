import React from "react";

const Footer = () => {
  return (
    <div className="footer">
      <h4>NANNAPANENI KARTHIKEYA</h4>
      <h4>20BQ1A05G3</h4>
      <h1>FED BLOG</h1>
    </div>
  );
};

export default Footer;
